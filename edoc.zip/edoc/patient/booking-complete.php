<?php
session_start();


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/PHPMailer.php';
require '../PHPMailer/SMTP.php';
require '../PHPMailer/Exception.php';


// Redirect to login if user not logged in or not patient
if (!isset($_SESSION["user"]) || $_SESSION["user"] == "" || $_SESSION['usertype'] != 'p') {
    header("Location: ../login.php");
    exit();
}

$useremail = $_SESSION["user"];

// Include DB connection
include("../connection.php");

// Fetch patient ID
$stmt = $database->prepare("SELECT * FROM patient WHERE pemail=?");
$stmt->bind_param("s", $useremail);
$stmt->execute();
$userfetch = $stmt->get_result()->fetch_assoc();
$userid = $userfetch["pid"];
$username = $userfetch["pname"];

// Proceed only if redirected from Razorpay with payment success
if (isset($_GET["payment"]) && $_GET["payment"] == "success") {
    
    // Make sure session has the appointment data
    if (isset($_SESSION["apponum"], $_SESSION["scheduleid"], $_SESSION["date"])) {
        $apponum = $_SESSION["apponum"];
        $scheduleid = $_SESSION["scheduleid"];
        $date = $_SESSION["date"];

        // Insert appointment
        $sql2 = "INSERT INTO appointment(pid, apponum, scheduleid, appodate) VALUES (?, ?, ?, ?)";
        $stmt2 = $database->prepare($sql2);
        $stmt2->bind_param("iiis", $userid, $apponum, $scheduleid, $date);
        $stmt2->execute();

        // Clear appointment session data
        unset($_SESSION["apponum"], $_SESSION["scheduleid"], $_SESSION["date"]);


        $mail = new PHPMailer(true);

        try {
            // SMTP Configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
        
            // Gmail credentials
            $mail->Username = 'varunjadhav247@gmail.com'; // your Gmail
            $mail->Password = 'vzfsrpvphwfseclj';    // app password (not Gmail password)
        
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
        
            // Sender and receiver
            $mail->setFrom('varunjadhav247@gmail.com', 'E-Doc Team');
            $mail->addAddress($useremail, $username);
        
            // Email content
            $mail->isHTML(true);
            $mail->Subject = "Booking Confirmation - Appointment #$apponum";
            $mail->Body    = "
                <h2>Dear $username,</h2>
                <p>Your appointment has been successfully booked.</p>
                <p><strong>Appointment Number:</strong> $apponum</p>
                <p><strong>Date:</strong> $date</p>
                <p><strong>Schedule ID:</strong> $scheduleid</p>
                <br>
                <p>Thank you for using our service.</p>
                <p><strong>- E-Doc Team</strong></p>
            ";
        //     $mail->SMTPDebug = 2; // or 3 for more
        // $mail->Debugoutput = 'html';
        
            $mail->send();
            echo '✅ Email sent successfully.';
        } catch (Exception $e) {
            echo "❌ Email could not be sent. Error: {$mail->ErrorInfo}";
        }

        // Redirect to success page
        header("Location: appointment.php?action=booking-added&id=$apponum&titleget=none");
        exit();

    } else {
        echo "⚠️ Booking details are missing. Please try again.";
    }

} else {
    echo "❌ Payment was not successful. Appointment not booked.<br>";
    echo "<a href='../patient/booking.php'>Go back to Booking Page</a>";
}
?>
