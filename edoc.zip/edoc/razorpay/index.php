<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

    require('razorpay-php/Razorpay.php');
    use Razorpay\Api\Api;

    $api_key  ='rzp_test_dp7xvgixuUEqUe';
    $api_secret = 'SkYooblrGdOC94XYTz11A9Hm';

    $api= new Api($api_key, $api_secret);

    // Create an order
    $order = $api->order->create([
        'amount'   => 50000, // amount in paise (100 paise = 1 rupee)
        'currency' => 'INR',
        'receipt'  => 'order_receipt_12asa3'
    ]);

    // Get the order ID
    $order_id = $order->id;
    
    // Set your callback URL
    // $callback_url = "http://localhost/edoc/razorpay/success.php";

    $callback_url = "http://localhost/edoc/razorpay/success.php";

    
    // Include Razorpay Checkout.js library
    echo '<script src="https://checkout.razorpay.com/v1/checkout.js"></script>';
    
    // Create a payment button with Checkout.js
    // echo '<button onclick="startPayment()">Pay with Razorpay</button>';
    
    // Add a script to handle the payment
    echo '<script>
        function startPayment() {
            var options = {
                key: "' . $api_key . '",
                amount: "' . $order->amount . '",
                currency: "' . $order->currency . '",
                name: "E-Doc",
                description: "Appointment scheduling fee",
                image: "https://cdn.razorpay.com/logos/GhROcyean79PgE_medium.png",
                order_id: "' . $order_id . '",
                theme: {
                    "color": "#738276"
                },
                callback_url: "' . $callback_url . '"
            };
            var rzp = new Razorpay(options);
            rzp.open();
        }

        // Auto-call on page load
    window.onload = startPayment;
    </script>';
    ?>
