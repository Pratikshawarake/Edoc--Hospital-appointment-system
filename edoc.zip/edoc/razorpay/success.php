<?php
// session_start();

// require('razorpay-php/Razorpay.php');

// use Razorpay\Api\Api;

// include("../connection.php");

// // Razorpay returns POST data here, you may validate if needed.

// if (isset($_SESSION['scheduleid'], $_SESSION['apponum'], $_SESSION['date'])) {



// if (!isset($_POST['razorpay_payment_id'])) {
//     die("No payment ID received.");
// }

// $payment_id = $_POST['razorpay_payment_id'];

// // Initialize Razorpay
// $api_key = 'rzp_test_dp7xvgixuUEqUe';
// $api_secret = 'SkYooblrGdOC94XYTz11A9Hm';
// $api = new Api($api_key, $api_secret);

// // Fetch payment details from Razorpay
// try {
//     $payment = $api->payment->fetch($payment_id);
// } catch (Exception $e) {
//     die("❌ Failed to fetch payment details: " . $e->getMessage());
// }

// // Get user email from session
// $user_email = $_SESSION['user'] ?? null;
// if (!$user_email) {
//     die("Unauthorized access.");
// }

// // Get patient ID from database
// $stmt = $database->prepare("SELECT pid FROM patient WHERE pemail = ?");
// $stmt->bind_param("s", $user_email);
// $stmt->execute();
// $result = $stmt->get_result();
// if ($result->num_rows === 0) {
//     die("Patient not found.");
// }
// $user_id = $result->fetch_assoc()['pid'];

// // Prepare payment data
// $created_at = date('Y-m-d H:i:s', $payment->created_at);
// $description = $payment->description ?? '';
// $bank = $payment->bank ?? '';
// $wallet = $payment->wallet ?? '';
// $vpa = $payment->vpa ?? '';
// $email = $payment->email ?? '';
// $contact = $payment->contact ?? '';

// // Insert into payments table
// $stmt = $database->prepare("
//     INSERT INTO payments 
//         (user_id, razorpay_payment_id, razorpay_order_id, status, method, amount, currency, email, contact, payment_date, description, bank, wallet, vpa) 
//     VALUES 
//         (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
// ");

// if (!$stmt) {
//     die("Prepare failed: " . $database->error);
// }

// $stmt->bind_param(
//     "isssssisssssss",
//     $user_id,
//     $payment->id,
//     $payment->order_id,
//     $payment->status,
//     $payment->method,
//     $payment->amount,
//     $payment->currency,
//     $email,
//     $contact,
//     $created_at,
//     $description,
//     $bank,
//     $wallet,
//     $vpa
// );

// if (!$stmt->execute()) {
//     die("❌ Failed to insert payment record: " . $stmt->error);
// }




//     // All good, redirect to booking-complete with flag
//     header("Location: ../patient/booking-complete.php?payment=success");
//     exit();
// } else {
//     echo "Booking session expired. Please try again.";
// }





// // // All done — Redirect to confirmation page
// // header("Location: ../patient/booking-complete.php?payment=success");
// // exit();




session_start();

require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;

include("../connection.php");

// ✅ Check if appointment booking data exists
if (isset($_SESSION['scheduleid'], $_SESSION['apponum'], $_SESSION['date'])) {

    // ✅ Check Razorpay payment ID
    if (!isset($_POST['razorpay_payment_id'])) {
        die("No payment ID received.");
    }

    $payment_id = $_POST['razorpay_payment_id'];

    // ✅ Initialize Razorpay
    $api_key = 'rzp_test_dp7xvgixuUEqUe';
    $api_secret = 'SkYooblrGdOC94XYTz11A9Hm';
    $api = new Api($api_key, $api_secret);

    // ✅ Fetch payment details
    try {
        $payment = $api->payment->fetch($payment_id);
    } catch (Exception $e) {
        die("❌ Failed to fetch payment details: " . $e->getMessage());
    }

    // ✅ Get logged-in user email
    $user_email = $_SESSION['user'] ?? null;
    if (!$user_email) {
        die("Unauthorized access.");
    }

    // ✅ Get user ID from DB
    $stmt = $database->prepare("SELECT pid FROM patient WHERE pemail = ?");
    $stmt->bind_param("s", $user_email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        die("Patient not found.");
    }
    $user_id = $result->fetch_assoc()['pid'];

    // ✅ Prepare and insert payment data
    $created_at = date('Y-m-d H:i:s', $payment->created_at);
    $description = $payment->description ?? '';
    $bank = $payment->bank ?? '';
    $wallet = $payment->wallet ?? '';
    $vpa = $payment->vpa ?? '';
    $email = $payment->email ?? '';
    $contact = $payment->contact ?? '';

    $stmt = $database->prepare("
        INSERT INTO payments 
            (user_id, razorpay_payment_id, razorpay_order_id, status, method, amount, currency, email, contact, payment_date, description, bank, wallet, vpa) 
        VALUES 
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        die("Prepare failed: " . $database->error);
    }

    $stmt->bind_param(
        "isssssisssssss",
        $user_id,
        $payment->id,
        $payment->order_id,
        $payment->status,
        $payment->method,
        $payment->amount,
        $payment->currency,
        $email,
        $contact,
        $created_at,
        $description,
        $bank,
        $wallet,
        $vpa
    );

    if (!$stmt->execute()) {
        die("❌ Failed to insert payment record: " . $stmt->error);
    }

    // ✅ Redirect to booking complete
    header("Location: ../patient/booking-complete.php?payment=success");
    exit();

} else {
    // ❌ Session expired or missing
    echo "Booking session expired. Please try again.";
}




?>
