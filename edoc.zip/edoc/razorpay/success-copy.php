<?php
require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;

$api_key = 'rzp_test_dp7xvgixuUEqUe';
$api_secret = 'SkYooblrGdOC94XYTz11A9Hm';

$api = new Api($api_key, $api_secret);

// Get payment ID from POST
$payment_id = $_POST['razorpay_payment_id'];

try {
    // Fetch payment details
    $payment = $api->payment->fetch($payment_id);
    $amount_inr = $payment->amount / 100;
    $created_at = date('Y-m-d H:i:s', $payment->created_at);
} catch (Exception $e) {
    echo "Error fetching payment details: " . $e->getMessage();
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Success</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f4f4f4;
            margin: 40px;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            max-width: 700px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.15);
        }
        h2 {
            color: green;
        }
        table {
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            width: 30%;
            background-color: #f0f0f0;
        }
        td {
            background-color: #fafafa;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>🎉 Payment Successful!</h2>
        <p>Thank you for your payment. Below are your payment details:</p>

        <table>
            <tr><th>Transaction ID</th><td><?= $payment->id ?></td></tr>
            <tr><th>Order ID</th><td><?= $payment->order_id ?></td></tr>
            <tr><th>Status</th><td><?= $payment->status ?></td></tr>
            <tr><th>Method</th><td><?= $payment->method ?></td></tr>
            <tr><th>Amount</th><td>₹<?= $amount_inr ?> <?= $payment->currency ?></td></tr>
            <tr><th>Email</th><td><?= $payment->email ?? 'N/A' ?></td></tr>
            <tr><th>Contact</th><td><?= $payment->contact ?? 'N/A' ?></td></tr>
            <tr><th>Date</th><td><?= $created_at ?></td></tr>
            <tr><th>Description</th><td><?= $payment->description ?? 'N/A' ?></td></tr>
            <tr><th>Bank</th><td><?= $payment->bank ?? 'N/A' ?></td></tr>
            <tr><th>Wallet</th><td><?= $payment->wallet ?? 'N/A' ?></td></tr>
            <tr><th>UPI ID (VPA)</th><td><?= $payment->vpa ?? 'N/A' ?></td></tr>
        </table>
    </div>
</body>
</html>
