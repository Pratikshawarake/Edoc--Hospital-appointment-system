<?php
session_start();
if(isset($_POST['booknow'])) {
    $_SESSION['scheduleid'] = $_POST['scheduleid'];
    $_SESSION['apponum'] = $_POST['apponum'];
    $_SESSION['date'] = $_POST['date'];
    header("Location: index.php");
    exit();
}
?>
