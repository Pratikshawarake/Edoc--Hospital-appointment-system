<?php
// Razorpay API configuration

$razorpay_config = array(
    'api_key'    => 'rzp_test_dp7xvgixuUEqUe',
    'api_secret' => 'SkYooblrGdOC94XYTz11A9Hm',
);

// Other configurations, if needed
?>
