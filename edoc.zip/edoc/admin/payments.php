<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
        
    <title>Payments</title>
    <style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style>

<style>
    .popup {
        animation: transitionIn-Y-bottom 0.5s;
    }
    .sub-table {
        animation: transitionIn-Y-bottom 0.5s;
        width: 90%;
        margin: auto;
        border-collapse: collapse;
        font-family: Arial, sans-serif;
        text-align: center;
    }
    .sub-table th, .sub-table td {
        padding: 12px;
        border: 1px solid #ddd;
    }
    .sub-table th {
        background-color: #ffffff;
        color: #333;
        font-weight: bold;
    }
    .sub-table tr:nth-child(even) {
        background-color: #fafafa;
    }
    .sub-table tr:hover {
        background-color: #f1f1f1;
    }
    .scroll {
        overflow-x: auto;
    }
</style>

</head>
<body>
    <?php

    //learn from w3schools.com

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }
    
    

    //import database
    include("../connection.php");

    
    ?>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title">Administrator</p>
                                    <p class="profile-subtitle">admin@edoc.com</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                    </table>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></a></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor ">
                        <a href="doctors.php" class="non-style-link-menu "><div><p class="menu-text">Doctors</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-schedule">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">Schedule</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">Appointment</p></a></div>
                    </td>
                </tr>
               <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">Payments</p></a></div>
                    </td>
                </tr>

                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-payments  menu-active menu-icon-payments-active">
                        <a href="payments.php" class="non-style-link-menu  non-style-link-menu-active"><div><p class="menu-text">Payments</p></a></div>
                    </td>
                </tr>

            </table>
        </div>







        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
                <tr >
                    <td width="13%">

                    <a href="payments.php" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                        
                    </td>
                    <td>
                        
                        <form action="" method="post" class="header-search">

                            <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Patient Name or Mobile" list="patient">&nbsp;&nbsp;
                            
                            <?php
                                echo '<datalist id="patient">';
                                // $list11 = $database->query("select  pname,pemail from patient;");

                                $list11 = $database->query("
    SELECT DISTINCT patient.pname, patient.pemail 
    FROM patient 
    JOIN payments ON patient.pid = payments.user_id;
");


                                for ($y=0;$y<$list11->num_rows;$y++){
                                    $row00=$list11->fetch_assoc();
                                    $d=$row00["pname"];
                                    $c=$row00["pemail"];
                                    echo "<option value='$d'><br/>";
                                    echo "<option value='$c'><br/>";
                                };

                            echo ' </datalist>';
?>
                            
                       
                            <input type="Submit" value="Search" class="login-btn btn-primary btn" style="padding-left: 25px;padding-right: 25px;padding-top: 10px;padding-bottom: 10px;">
                        
                        </form>
                        






                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                        date_default_timezone_set('Asia/Kolkata');

                        $date = date('Y-m-d');
                        echo $date;
                        ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                    </td>


                </tr>
               
                
                <tr>
                    <td colspan="4" style="padding-top:10px;">
                        <p class="heading-main12" style="margin-left: 45px;font-size:18px;color:rgb(49, 49, 49)">All Payments (<?php echo $list11->num_rows; ?>)</p>
                    </td>
                    
                </tr>
                <?php
                    // if($_POST){
                    //     $keyword=$_POST["search"];
                        
                    //     $sqlmain= "select * from patient where pemail='$keyword' or pname='$keyword' or pname like '$keyword%' or pname like '%$keyword' or pname like '%$keyword%' ";
                    // }else{
                    //     $sqlmain= "select * from patient order by pid desc";

                    // }


                    
					if ($_POST) {
					    $keyword = $_POST["search"];
					
					    $sqlmain = "
					    SELECT 
					            patient.pname AS patient_name,
					            patient.ptel AS patient_mobile,
					            payments.id,
					            payments.amount,
					            payments.method,
					            payments.status,
					            payments.payment_date,
					            payments.razorpay_payment_id
					        FROM 
					            payments
					        JOIN 
					            patient ON patient.pid = payments.user_id
					        WHERE 
					            patient.pname = '$keyword'
					            OR patient.ptel = '$keyword'
					            OR patient.pname LIKE '$keyword%' 
					            OR patient.pname LIKE '%$keyword' 
					            OR patient.pname LIKE '%$keyword%'
					            OR patient.ptel LIKE '$keyword%'
					            OR patient.ptel LIKE '%$keyword'
					            OR patient.ptel LIKE '%$keyword%'
					        ORDER BY 
					            payments.id ASC
					    ";
					} else {
					    $sqlmain = "
					        SELECT 
					            patient.pname AS patient_name,
					            patient.ptel AS patient_mobile,
					            payments.id,
					            payments.amount,
					            payments.method,
					            payments.status,
					            payments.payment_date,
					            payments.razorpay_payment_id
					        FROM 
					            payments
					        JOIN 
					            patient ON patient.pid = payments.user_id
					        ORDER BY 
					            payments.id ASC
					    ";
					}
					?>



                <tr>



                   <td colspan="4">
                       <center>
                        <div class="abc scroll">
                        <table width="93%" class="sub-table scrolldown"  style="border-spacing:0;">
                        <thead>
                        <tr>
                                <th class="table-headin">
                                    
                                
                                ID
                                
                                </th>
                                <th class="table-headin">
                                    
                                
                                    Patient Name
                                    
                                </th>
                                <th class="table-headin">
                                    
                                
                                    Mobile No.
                                    
                                </th>
                                <th class="table-headin">
                                
                            
                                Amount
                                
                                </th>
                                <th class="table-headin">
                                    Payment Method	
                                </th>
                                <th class="table-headin">
                                    
									Payment Status	                                    
                                </th>
                                <th class="table-headin">
                                    
									Payment Date	        
								</th>
                                <th class="table-headin">
                                    
									Razorpay Payment ID		                                    
                                </th>
                                
                        </thead>








                        
                        <tbody>
                        
                            <?php

                                
                                $result= $database->query($sqlmain);

                                if($result->num_rows==0){
                                    echo '<tr>
                                    <td colspan="8">
                                    <br><br><br><br>
                                    <center>
                                    <img src="../img/notfound.svg" width="25%">
                                    
                                    <br>
                                    <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">We  couldnt find anything related to your keywords !</p>
                                    <a class="non-style-link" href="payments.php"><button  class="login-btn btn-primary-soft btn"  style="display: flex;justify-content: center;align-items: center;margin-left:20px;">&nbsp; Show all Payments &nbsp;</font></button>
                                    </a>
                                    </center>
                                    <br><br><br><br>
                                    </td>
                                    </tr>';
                                    
                                }
                                else{
                                for ($x = 0; $x < $result->num_rows; $x++) {
    								$row = $result->fetch_assoc();
									$id = $row["id"];
    								$patient_name = $row["patient_name"];
    								$patient_mobile = $row["patient_mobile"];
    								$amount = $row["amount"]/100;
    								$method = $row["method"];
    								$status = $row["status"];
    								$payment_date = $row["payment_date"];
    								$razorpay_payment_id = $row["razorpay_payment_id"];
								
    								echo '<tr>
    								<center>
    									<td>' . $id . '</td>
    								    <td>' . substr($patient_name, 0, 35) . '</td>
    								    <td>' . substr($patient_mobile, 0, 10) . '</td>
    								    <td>' . $amount . '</td>
    								    <td>' . $method . '</td>
    								    <td>' . $status . '</td>
    								    <td>' . substr($payment_date, 0, 10) . '</td>
    								    <td>' . $razorpay_payment_id . '</td>
                                     
                                        </center>
                                    </tr>';
                                    
                                }
                            }
                                 
                            ?>
 
                            </tbody>

                        </table>
                        </div>
                        </center>
                   </td> 
                </tr>
                       
                        
                        
            </table>
        </div>
    </div>
    
</div>

</body>
</html>